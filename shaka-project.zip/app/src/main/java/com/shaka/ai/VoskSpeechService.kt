package com.shaka.ai

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat

/**
 * Android Foreground Service for Vosk Microphone Access.
 * 
 * CRITICAL ANDROID RESTRICTION NOTICE:
 * Starting in Android 9 (Pie) and reinforced in Android 14/15:
 * Background microphone recording without a visible Foreground Service is strictly blocked by the OS.
 * Apps claiming to "silently and invisibly listen in background 24/7" will be killed by Android OS.
 * Shaka AI uses a transparent Foreground Service with FOREGROUND_SERVICE_MICROPHONE.
 */
class VoskSpeechService : Service() {

    companion object {
        const val CHANNEL_ID = "ShakaVoiceServiceChannel"
        const val NOTIFICATION_ID = 1001
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val notification = createNotification()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }

        return START_STICKY
    }

    private fun createNotification(): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("SHAKA AI Voice Radar")
            .setContentText("Listening for 'Hey Shaka' wake phrase (Offline Vosk)")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOngoing(true)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "SHAKA AI Assistant Channel",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Vosk Offline Wake-Word Recognition"
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
