package com.shaka.ai

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import org.vosk.android.SpeechService
import org.vosk.android.StorageService
import java.io.IOException
import java.util.Locale

class MainActivity : ComponentActivity(), RecognitionListener, TextToSpeech.OnInitListener {

    private var model: Model? = null
    private var speechService: SpeechService? = null
    private var tts: TextToSpeech? = null
    private val intentDispatcher = IntentDispatcher(this)

    // State holders
    private val _isListening = mutableStateOf(false)
    private val _isAwake = mutableStateOf(false)
    private val _statusText = mutableStateOf("Vosk model tayyar ho raha hai...")
    private val _chatMessages = mutableStateListOf<ChatMessage>()
    private val _pendingConfirmation = mutableStateOf<PendingAction?>(null)

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            initVoskModel()
        } else {
            _statusText.value = "Microphone permission zaroori hai voice recognition ke liye!"
            Toast.makeText(this, "Permission lazmi dein!", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        tts = TextToSpeech(this, this)
        
        checkMicrophonePermission()

        setContent {
            ShakaTheme {
                ShakaAssistantScreen(
                    isListening = _isListening.value,
                    isAwake = _isAwake.value,
                    statusText = _statusText.value,
                    messages = _chatMessages,
                    pendingAction = _pendingConfirmation.value,
                    onToggleListening = { toggleListening() },
                    onConfirm = { handleConfirmation(true) },
                    onCancel = { handleConfirmation(false) }
                )
            }
        }
    }

    private fun checkMicrophonePermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            == PackageManager.PERMISSION_GRANTED
        ) {
            initVoskModel()
        } else {
            permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    private fun initVoskModel() {
        _statusText.value = "Offline Vosk model unpack ho raha hai..."
        StorageService.unpack(this, "model-en-us", "model",
            { unpackedModel: Model ->
                this.model = unpackedModel
                _statusText.value = "SHAKA AI hazir hai. 'Hey Shaka' bolein."
                startListening()
            },
            { exception: IOException ->
                _statusText.value = "Model load fail hua: ${exception.message}"
            }
        )
    }

    private fun startListening() {
        val currentModel = model ?: return
        try {
            val rec = Recognizer(currentModel, 16000.0f)
            speechService = SpeechService(rec, 16000.0f)
            speechService?.startListening(this)
            _isListening.value = true
        } catch (e: Exception) {
            _statusText.value = "Listening start na ho saki: ${e.message}"
        }
    }

    private fun toggleListening() {
        if (_isListening.value) {
            speechService?.stop()
            _isListening.value = false
            _statusText.value = "Mic paused. Tap karein start karne ke liye."
        } else {
            startListening()
        }
    }

    // Vosk Offline Speech Recognition Callbacks
    override fun onResult(hypothesis: String?) {
        hypothesis?.let { processSpeechText(it, isFinal = true) }
    }

    override fun onFinalResult(hypothesis: String?) {
        hypothesis?.let { processSpeechText(it, isFinal = true) }
    }

    override fun onPartialResult(hypothesis: String?) {
        // Realtime interim hypotheses can be displayed here
    }

    override fun onError(e: Exception?) {
        _statusText.value = "Speech recognition error: ${e?.message}"
    }

    override fun onTimeout() {
        startListening()
    }

    private fun processSpeechText(rawJson: String, isFinal: Boolean) {
        // Extract clean text from Vosk JSON response: {"text": "hey shaka open whatsapp"}
        val text = parseVoskText(rawJson).lowercase().trim()
        if (text.isEmpty()) return

        // 1. Handle Pending Confirmation
        val pending = _pendingConfirmation.value
        if (pending != null) {
            if (text.contains("haan") || text.contains("yes") || text.contains("pakka") || text.contains("kardo")) {
                handleConfirmation(true)
            } else if (text.contains("nahi") || text.contains("no") || text.contains("cancel") || text.contains("rok")) {
                handleConfirmation(false)
            }
            return
        }

        // 2. Check for Wake Phrase "Hey Shaka"
        val hasWake = text.contains("hey shaka") || text.contains("shaka")
        if (hasWake) {
            _isAwake.value = true
            val stripped = text.replace("hey shaka", "").replace("shaka", "").trim()
            
            if (stripped.isEmpty()) {
                val greeting = "Ji boss, Shaka hazir hai! Hukam karein."
                addMessage("User", "Hey Shaka")
                addMessage("Shaka", greeting)
                speakRomanUrdu(greeting)
                return
            } else {
                executeCommand(stripped)
            }
        } else {
            // Wake phrase check: ignore commands if not awake
            if (!_isAwake.value) {
                // Do nothing or remind user
                return
            }
            executeCommand(text)
        }
    }

    private fun executeCommand(command: String) {
        addMessage("User", command)

        when {
            // WhatsApp intent
            command.contains("whatsapp") -> {
                val reply = "Ji boss, WhatsApp khol raha hoon."
                addMessage("Shaka", reply)
                speakRomanUrdu(reply)
                intentDispatcher.openWhatsApp()
            }

            // Wi-Fi settings redirect (Android 10+ limitation compliance)
            command.contains("wifi") || command.contains("wi-fi") -> {
                val reply = "Boss, Android 10+ restrictions ki wajah se apps background se Wi-Fi seedha switch nahi kar saktein. Main Wi-Fi Settings open kar raha hoon taake aap khud toggle karein."
                addMessage("Shaka", reply)
                speakRomanUrdu(reply)
                intentDispatcher.openWifiSettings()
            }

            // Risky Action: Send Money
            command.contains("paise") || command.contains("money") || command.contains("transfer") -> {
                val prompt = "Kya main pakka karoon? Yeh maali transaction hai."
                _pendingConfirmation.value = PendingAction("SEND_MONEY", prompt)
                addMessage("Shaka", prompt)
                speakRomanUrdu(prompt)
            }

            // Risky Action: Delete Data
            command.contains("delete") || command.contains("mita") -> {
                val prompt = "Kya main pakka karoon? Saara data delete ho jayega."
                _pendingConfirmation.value = PendingAction("DELETE_DATA", prompt)
                addMessage("Shaka", prompt)
                speakRomanUrdu(prompt)
            }

            // Camera Intent
            command.contains("camera") || command.contains("tasveer") -> {
                val reply = "Ji boss, camera launch kar raha hoon."
                addMessage("Shaka", reply)
                speakRomanUrdu(reply)
                intentDispatcher.openCamera()
            }

            // Fallback Roman Urdu Response
            else -> {
                val reply = "Boss, hukam sun liya hai. Android intents par kaam chal raha hai."
                addMessage("Shaka", reply)
                speakRomanUrdu(reply)
            }
        }
    }

    private fun handleConfirmation(confirmed: Boolean) {
        val pending = _pendingConfirmation.value ?: return
        _pendingConfirmation.value = null
        if (confirmed) {
            val reply = "Ji boss, tasdeeq ho gayi hai. Amal execute kar diya gaya hai."
            addMessage("Shaka", reply)
            speakRomanUrdu(reply)
        } else {
            val reply = "Ji boss, yeh action cancel kar diya gaya hai."
            addMessage("Shaka", reply)
            speakRomanUrdu(reply)
        }
    }

    private fun speakRomanUrdu(text: String) {
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "ShakaTTS")
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale("ur", "PK")
        }
    }

    private fun addMessage(sender: String, message: String) {
        _chatMessages.add(ChatMessage(sender, message, System.currentTimeMillis()))
    }

    private fun parseVoskText(json: String): String {
        return try {
            val regex = "\"text\"\\s*:\\s*\"([^\"]*)\"".toRegex()
            regex.find(json)?.groups?.get(1)?.value ?: ""
        } catch (e: Exception) {
            ""
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        speechService?.stop()
        speechService?.shutdown()
        tts?.shutdown()
    }
}

data class ChatMessage(val sender: String, val text: String, val timestamp: Long)
data class PendingAction(val type: String, val prompt: String)
