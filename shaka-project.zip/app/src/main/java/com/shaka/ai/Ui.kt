package com.shaka.ai

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun ShakaTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = darkColorScheme(), content = content)
}

@Composable
fun ShakaAssistantScreen(
    isListening: Boolean,
    isAwake: Boolean,
    statusText: String,
    messages: List<ChatMessage>,
    pendingAction: PendingAction?,
    onToggleListening: () -> Unit,
    onConfirm: () -> Unit,
    onCancel: () -> Unit
) {
    Surface(modifier = Modifier.fillMaxSize(), color = Color(0xFF0B0F1A)) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(16.dp)
        ) {
            Text("SHAKA AI", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Color.White)
            Text(
                statusText,
                color = if (isAwake) Color(0xFF4ADE80) else Color(0xFF9CA3AF),
                fontSize = 14.sp,
                modifier = Modifier.padding(top = 4.dp, bottom = 12.dp)
            )

            LazyColumn(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(messages) { m ->
                    val isUser = m.sender == "User"
                    Box(
                        modifier = Modifier.fillMaxWidth(),
                        contentAlignment = if (isUser) Alignment.CenterEnd else Alignment.CenterStart
                    ) {
                        Text(
                            m.text,
                            color = Color.White,
                            modifier = Modifier
                                .background(
                                    if (isUser) Color(0xFF1D4ED8) else Color(0xFF1F2937),
                                    RoundedCornerShape(12.dp)
                                )
                                .padding(horizontal = 12.dp, vertical = 8.dp)
                        )
                    }
                }
            }

            if (pendingAction != null) {
                Text(pendingAction.prompt, color = Color(0xFFFBBF24), modifier = Modifier.padding(vertical = 8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = onConfirm) { Text("Haan") }
                    OutlinedButton(onClick = onCancel) { Text("Nahi") }
                }
            }

            Button(
                onClick = onToggleListening,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 12.dp)
            ) {
                Text(if (isListening) "Mic band karein" else "Mic shuru karein")
            }
        }
    }
}
