package com.shaka.ai

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.MediaStore
import android.provider.Settings
import android.widget.Toast

class IntentDispatcher(private val context: Context) {

    /**
     * WhatsApp Intent: Opens WhatsApp using whatsapp:// or web fallback
     */
    fun openWhatsApp() {
        try {
            val intent = Intent(Intent.ACTION_VIEW).apply {
                data = Uri.parse("whatsapp://send")
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            try {
                val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/")).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(webIntent)
            } catch (e2: Exception) {
                Toast.makeText(context, "WhatsApp install nahi hai!", Toast.LENGTH_SHORT).show()
            }
        }
    }

    /**
     * Wi-Fi Settings Intent:
     * NOTE: Android 10+ (API 29+) explicitly deprecates and restricts WifiManager.setWifiEnabled()
     * for third-party apps for security and privacy.
     * Attempting to force toggle causes SecurityException or silent failure.
     * Honest implementation: Launch Settings.ACTION_WIFI_SETTINGS directly for the user!
     */
    fun openWifiSettings() {
        try {
            val intent = Intent(Settings.ACTION_WIFI_SETTINGS).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            val generalIntent = Intent(Settings.ACTION_SETTINGS).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(generalIntent)
        }
    }

    fun openCamera() {
        try {
            val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(context, "Camera open nahi ho saka", Toast.LENGTH_SHORT).show()
        }
    }

    fun openDialer() {
        try {
            val intent = Intent(Intent.ACTION_DIAL).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(context, "Dialer open nahi ho saka", Toast.LENGTH_SHORT).show()
        }
    }
}
