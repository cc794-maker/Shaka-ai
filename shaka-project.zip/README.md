# SHAKA AI - Asli Android Voice Assistant

Asli Android assistant jo Vosk offline speech recognition use karta hai, English, Roman Urdu aur Hinglish commands samajhta hai, aur tamam jawab Roman Urdu mein deta hai.

## 1. Wake Phrase
- **Wake Phrase**: "Hey Shaka"
- **Jawab**: "Ji boss, Shaka hazir hai! Hukam karein."
- **Strict Rule**: Wake phrase ke baghair Shaka kisi command par amal nahi karega.

## 2. Phone par Install aur Permissions dene ke Steps
1. **APK Download karein**:
   - `ShakaAI-v1.0-release.apk` download karein.
2. **Android Settings**:
   - Phone Settings -> Security -> "Install Unknown Apps" enable karein.
3. **App Open karein**:
   - Pehli martaba kholne par Microphone permission (`RECORD_AUDIO`) ka dialog aayega; **Allow** karein.
4. **Vosk Offline Model**:
   - App pehli dafa offline model unpack karegi (~10 seconds). Internet ki zaroorat nahi hai.
5. **Commands Bolein**:
   - "Hey Shaka" bolein.
   - Response: "Ji boss, Shaka hazir hai! Hukam karein."
   - "WhatsApp kholo" -> WhatsApp khol dega.
   - "Wi-Fi settings open karo" -> Android settings open karega.
   - "Ali ko 500 rupay bhejo" -> "Kya main pakka karoon?" poochhega.

## 3. Android Limitations & Privacy Honesty (Chhup kar chalne ka dawa nahi)
- **Background Microphone Access**: Android 9+ aur Android 14/15 mein koi bhi app background mein chhup kar mic nahi sun sakti. Shaka AI ek transparent Foreground Service aur status bar notification use karta hai.
- **Wi-Fi Toggle Restriction**: Android 10+ (API 29+) ne security ke tehat 3P apps ke liye direct Wi-Fi switch karna block kar diya hai. Is liye Shaka direct `Settings.ACTION_WIFI_SETTINGS` kholta hai taake user khud toggle kare.
- **Safety Confirmations**: Paise bhejna, data delete karna ya messages bhejne se pehle Shaka lazmi poochhta hai: "Kya main pakka karoon?".
