# Liza AI Assistant for Android

Liza is a starter Android app for voice and typed commands. It can launch several common apps, open a web search, prepare a phone call in the dialer, open an SMS composer, and request a timer. It does not contain an online AI model; commands are handled locally with a small phrase matcher.

## Get the APK from GitHub

1. Create a new GitHub repository and upload the contents of this folder (the files inside `Liza/`, not the enclosing zip folder).
2. Open **Actions** and run **Build Liza APK** (or push to `main`/`master`).
3. Open the successful workflow run and download the `Liza-debug-apk` artifact. The APK is `app-debug.apk` inside the downloaded artifact.
4. Install the APK on your Android phone. Android may ask you to allow installation from your browser/file manager.

The APK is a debug build signed by GitHub's Android build tools. For publishing on Google Play, make a release build and sign it with your own private key; do not share that key.

## Build locally

Requires JDK 17, Android SDK platform 35, and Gradle 8.9:

```sh
gradle assembleDebug
```

Output: `app/build/outputs/apk/debug/app-debug.apk`.

## Features

- Typed commands and Android speech recognition; tap **Speak** and grant microphone permission.
- Speech recognition uses the recognition service on your phone, which may support multiple languages. Choose/set its language in the recognition service or device settings when needed.
- Text-to-speech uses the phone's default language and installed voice. Availability and quality for Roman Urdu, Urdu, English, and other languages depend on the installed speech services.
- App shortcuts: Settings, Camera, YouTube, Maps, browser, WhatsApp, dialer, Clock, and Calculator (availability differs by phone).
- Web search, timer screen, dialer, and SMS composer actions.

Example commands: `open settings`, `YouTube kholo`, `search weather`, `call 03001234567`, `message Hello`, `set timer 5 minutes`.

## Important call limitation

Liza does not answer incoming calls or speak into a cellular call. Android requires a user-selected default dialer for call answering controls; even then, ordinary Android app APIs do not provide a supported way to inject generated assistant speech into the other side of a carrier call. This starter deliberately does not request call-log, phone-state, or call-answer permissions. Use your carrier voicemail or a supported call-screening service for missed-call responses.

## Privacy

Commands are matched on-device. Voice recognition is provided by the device's selected speech service and may send audio to its provider, depending on that service's settings. Liza itself has no server or API key.
