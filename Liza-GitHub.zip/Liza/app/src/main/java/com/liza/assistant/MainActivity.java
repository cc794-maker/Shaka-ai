package com.liza.assistant;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity implements TextToSpeech.OnInitListener {
    private static final int VOICE = 41, MIC = 42;
    private TextView chat;
    private EditText input;
    private ScrollView scroll;
    private TextToSpeech tts;
    private boolean ttsReady;

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        getWindow().setStatusBarColor(0xff211a2c);
        getWindow().setNavigationBarColor(0xff211a2c);
        buildUi();
        tts = new TextToSpeech(this, this);
        line("Liza", "Hi! Main Liza AI hoon, boss ki assistant. Type ya mic se command dein.\n\nI can open apps, search the web, start a timer, and prepare calls or messages.");
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(18),dp(18),dp(18),dp(12)); root.setBackgroundColor(0xfff5f2fa);
        TextView title = new TextView(this); title.setText("LIZA  ✦  AI ASSISTANT"); title.setTextSize(23); title.setTextColor(0xff392d4e); title.setGravity(Gravity.CENTER); title.setPadding(4,dp(12),4,dp(16)); title.setTypeface(null,1); root.addView(title);
        scroll = new ScrollView(this); scroll.setFillViewport(true); scroll.setBackgroundColor(0xffffffff); scroll.setPadding(dp(12),dp(12),dp(12),dp(12));
        chat = new TextView(this); chat.setTextSize(17); chat.setTextColor(0xff22202a); chat.setTextIsSelectable(true); chat.setLineSpacing(dp(3),1f); scroll.addView(chat,new ScrollView.LayoutParams(-1,-2)); root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        input = new EditText(this); input.setSingleLine(true); input.setHint("Type a command / apna command likhein"); input.setImeOptions(EditorInfo.IME_ACTION_SEND); root.addView(input,new LinearLayout.LayoutParams(-1,-2));
        LinearLayout buttons = new LinearLayout(this); buttons.setOrientation(LinearLayout.HORIZONTAL);
        Button mic = new Button(this); mic.setText("🎙 Speak"); Button send = new Button(this); send.setText("Send"); buttons.addView(mic,new LinearLayout.LayoutParams(0,-2,1)); buttons.addView(send,new LinearLayout.LayoutParams(0,-2,1)); root.addView(buttons);
        TextView note = new TextView(this); note.setText("Voice recognition/TTS languages depend on your phone. Calls need your confirmation."); note.setTextSize(12); note.setTextColor(0xff625e68); note.setPadding(4,dp(8),4,0); root.addView(note);
        setContentView(root);
        send.setOnClickListener(v -> submit()); mic.setOnClickListener(v -> startVoice());
        input.setOnEditorActionListener((v, action, event) -> { submit(); return true; });
    }
    private int dp(int n){ return (int)(n*getResources().getDisplayMetrics().density+0.5f); }
    private void submit(){ String s=input.getText().toString().trim(); if(s.isEmpty())return; input.setText(""); line("You",s); handle(s); }
    private void line(String who,String s){ chat.append(who+": "+s+"\n\n"); scroll.post(() -> scroll.fullScroll(View.FOCUS_DOWN)); }
    private void say(String s){ line("Liza",s); if(ttsReady) tts.speak(s,TextToSpeech.QUEUE_FLUSH,null,"liza-reply"); }
    private void startVoice(){
        if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){ requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},MIC); return; }
        if(!SpeechRecognizer.isRecognitionAvailable(this)){ say("Speech recognition is not available on this phone. Please type your command."); return; }
        Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH); i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM); i.putExtra(RecognizerIntent.EXTRA_PROMPT,"Speak in your preferred language"); i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS,3);
        try{startActivityForResult(i,VOICE);}catch(ActivityNotFoundException e){say("Voice recognition service is unavailable. You can type instead.");}
    }
    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){super.onRequestPermissionsResult(r,p,g);if(r==MIC&&g.length>0&&g[0]==PackageManager.PERMISSION_GRANTED)startVoice();else if(r==MIC)say("Microphone permission is needed for voice input.");}
    @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(r==VOICE&&c==RESULT_OK&&d!=null){ArrayList<String>a=d.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);if(a!=null&&!a.isEmpty()){line("You",a.get(0));handle(a.get(0));}}}

    private void handle(String raw){
        String s=raw.trim(), l=s.toLowerCase(Locale.ROOT);
        if(has(l,"hello","hi","salam","assalam","السلام علیکم","ہیلو")){say("Wa alaikum assalam! Main Liza hoon. Aap kya karwana chahte hain?");return;}
        if(has(l,"your name","tumhara naam","aap ka naam","تمہارا نام","آپ کا نام")){say("My name is Liza. Main boss ki AI assistant hoon.");return;}
        String number=extractNumber(s,l);
        if(number!=null){launch(new Intent(Intent.ACTION_DIAL,Uri.parse("tel:"+number)),"Dialer opened. Please review and place the call yourself.");return;}
        String sms=afterAny(s,l,"message ","sms ","text ","paigham ","پیغام ");
        if(sms!=null){try{Intent i=new Intent(Intent.ACTION_SENDTO,Uri.parse("smsto:"));i.putExtra("sms_body",sms);launch(i,"Message composer opened. Please check the recipient and send it yourself.");}catch(Exception e){say("Could not open messaging.");}return;}
        if(has(l,"timer","set timer","ٹائمر","timer lagao")){java.util.regex.Matcher m=java.util.regex.Pattern.compile("(\\d{1,3})\\s*(min|minute|minutes|mins|sec|second|seconds|سیکنڈ|منٹ)",java.util.regex.Pattern.CASE_INSENSITIVE).matcher(l);if(m.find()){int n=Integer.parseInt(m.group(1));String u=m.group(2);int sec=n*(u.startsWith("min")||u.equals("منٹ")?60:1);Intent i=new Intent("android.intent.action.SET_TIMER");i.putExtra("android.intent.extra.LENGTH",sec);i.putExtra("android.intent.extra.MESSAGE","Liza timer");launch(i,"Timer screen opened.");}else say("Tell me a duration, for example: set timer 5 minutes.");return;}
        String q=afterAny(s,l,"search for ","search ","google ","find ","talaash karo ","dhoondo ","تلاش کرو ","ڈھونڈو ");
        if(q!=null&&!q.isEmpty()){try{launch(new Intent(Intent.ACTION_VIEW,Uri.parse("https://www.google.com/search?q="+URLEncoder.encode(q,"UTF-8"))),"Search opened in your browser.");}catch(Exception e){say("Could not open search.");}return;}
        String app=getApp(l);
        if(app!=null){openApp(app);return;}
        if(has(l,"call","phone uthao","answer call","auto answer","کال اٹھاؤ")){say("Android does not let a regular assistant app automatically answer and speak on a mobile call. I can open the dialer when you ask to call a number.");return;}
        say("I did not understand that yet. Try: open settings, open YouTube, search weather, call 03001234567, or set timer 5 minutes.");
    }
    private boolean has(String s,String... words){for(String w:words)if(s.contains(w))return true;return false;}
    private String afterAny(String raw,String low,String... starts){for(String x:starts)if(low.startsWith(x))return raw.substring(x.length()).trim();return null;}
    private String extractNumber(String raw,String low){String[] starts={"call ","call karo ","dial ","number milao ","kall karo ","نمبر ملاؤ ","کال کرو "};for(String p:starts)if(low.startsWith(p)){String n=raw.substring(p.length()).replaceAll("[^+0-9]","");return n.length()>=3?n:null;}return null;}
    private String getApp(String l){if(!has(l,"open ","kholo ","khol do ","کھولو","کھول دو") && !l.endsWith(" kholo") && !l.endsWith(" khol do"))return null;
        if(has(l,"settings","setting","سیٹنگ"))return "settings"; if(has(l,"youtube","یوٹیوب"))return "youtube"; if(has(l,"camera","کیمرا","کیمرہ"))return "camera"; if(has(l,"maps","map","نقشہ"))return "maps"; if(has(l,"chrome","browser","کروم"))return "browser"; if(has(l,"whatsapp","واٹس ایپ"))return "whatsapp"; if(has(l,"phone","dialer"))return "dialer"; if(has(l,"clock","گھڑی"))return "clock"; if(has(l,"calculator","calculate","کیلکولیٹر"))return "calculator"; return null;}
    private void openApp(String key){
        if(key.equals("settings")){launch(new Intent(android.provider.Settings.ACTION_SETTINGS),"Settings opened.");return;}
        if(key.equals("camera")){launch(new Intent("android.media.action.IMAGE_CAPTURE"),"Camera opened.");return;}
        if(key.equals("dialer")){launch(new Intent(Intent.ACTION_DIAL),"Dialer opened.");return;}
        if(key.equals("clock")){launch(new Intent("android.intent.action.SHOW_ALARMS"),"Clock opened.");return;}
        String[] candidates;
        switch(key){case "youtube": candidates=new String[]{"com.google.android.youtube"};break;case "maps":candidates=new String[]{"com.google.android.apps.maps"};break;case "browser":candidates=new String[]{"com.android.chrome","org.mozilla.firefox","com.brave.browser"};break;case "whatsapp":candidates=new String[]{"com.whatsapp"};break;default:candidates=new String[]{"com.google.android.calculator","com.android.calculator2"};}
        PackageManager pm=getPackageManager();for(String p:candidates){Intent i=pm.getLaunchIntentForPackage(p);if(i!=null){launch(i,"Opening "+key+".");return;}}say("That app is not installed or its package is different on this phone.");
    }
    private void launch(Intent i,String ok){try{startActivity(i);say(ok);}catch(ActivityNotFoundException e){say("No compatible app was found on this phone.");}catch(SecurityException e){say("Android blocked that action. Check this app’s permissions and try again.");}}
    @Override public void onInit(int status){if(status==TextToSpeech.SUCCESS){int r=tts.setLanguage(Locale.getDefault());ttsReady=r!=TextToSpeech.LANG_MISSING_DATA&&r!=TextToSpeech.LANG_NOT_SUPPORTED;}}
    @Override protected void onDestroy(){if(tts!=null){tts.stop();tts.shutdown();}super.onDestroy();}
}
